# V2Manager 已编译
## 适用于V2raySocks 后端
### 使用方法:
修改好“config.json”配置文件
执行
 '''
./go.sh
 '''
再执行
./main

测试没问题 用screen把这个进程挂起！
